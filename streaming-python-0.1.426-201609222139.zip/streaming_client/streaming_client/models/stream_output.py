from .stream_output_internal import StreamOutputInternal

import getpass

class StreamOutput(StreamOutputInternal):
    def __init__(self, name, connection_name, target_config = {}):
        super(self.__class__,self).__init__()

        # provided by user
        self._name = name
        self._target_config = target_config
        self._connection_name = connection_name

        # not provided by user
        self._type = "kafka"
        self._format = "json"
        self._token = "Bearer " + getpass.getpass('ibm.ax.token')
        self._orgid = getpass.getpass('ibm.ax.orgid')
