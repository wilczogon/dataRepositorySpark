from .stream_internal import StreamInternal

class Stream(StreamInternal):
    def __init__(self, name, object_string, inputs, outputs, pipeline_type, spark_service_guid):

        super(self.__class__,self).__init__()

        self._name = name
        self._object_string = object_string
        self._inputs = inputs
        self._outputs = outputs
        self._pipeline_type = pipeline_type
        self._spark_service_guid = spark_service_guid