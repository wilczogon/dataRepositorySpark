pipeline.Sink module
======================

Module Context
--------------

.. automodule:: pipeline.Sink
    :members:
    :undoc-members:
