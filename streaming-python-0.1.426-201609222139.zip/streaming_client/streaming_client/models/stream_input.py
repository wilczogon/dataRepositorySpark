from .stream_input_internal import StreamInputInternal

import getpass

class StreamInput(StreamInputInternal):
    def __init__(self, name, schema, connection_name):
        super(self.__class__,self).__init__()

        # provided by user
        self._name = name
        self._schema = schema
        self._connection_name = connection_name

        # not provided by user
        self._type = "kafka"
        self._format = "json"
        self._token = "Bearer " + getpass.getpass('ibm.ax.token')
        self._orgid = getpass.getpass('ibm.ax.orgid')
        self.target_config = {}
