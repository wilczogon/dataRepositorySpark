from setuptools import setup

VERSION='0.1.53-201701020606'
setup(name='repository',
      version=VERSION,
      description='Repository Library',
      url='https://github.ibm.com/NGP-TWC/repository/',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=['src/repository'],
      zip_safe=False)
