import base64
import json

from swagger_client.api_client import ApiClient

from swagger_client.rest import ApiException

try:
    import urllib3
except ImportError:
    raise ImportError('urllib3 is missing')

try:
    # for python3
    from urllib.parse import urlencode
except ImportError:
    # for python2
    from urllib import urlencode

http = urllib3.PoolManager()


class MLApiClient(ApiClient):
    def __init__(self, repository_path, token_endpoint_path=None):
        super(MLApiClient, self).__init__(repository_path)
        self.repository_path = repository_path
        self.token_endpoint_path = token_endpoint_path if token_endpoint_path is not None else repository_path
        self.token = None

    def authorize_with_password(self, user, password):
        encoded_credentials = base64.b64encode('{}:{}'.format(user, password))
        r = http.request('GET', '{}/v2/identity/token'.format(self.token_endpoint_path),
            headers={
                'Authorization': 'Basic {}'.format(encoded_credentials)
            }
        )
        self.authorize_with_token(json.loads(r.data).get('token'))

    def authorize_with_token(self, token):
        self.token = token
        self.set_default_header('Authorization', 'Bearer {}'.format(token))

    def is_authorized(self):
        return self.token is not None

    def upload_pipeline_version(self, pipeline_id, version_id, binary_data):
        r = http.request('PUT', '{}/v2/artifacts/pipelines/{}/versions/{}/content'.format(
            self.repository_path,
            pipeline_id,
            version_id
        ),
            headers=self._get_headers(),
            body=binary_data
        )
        if r.status != 200:
            raise ApiException(r.status)

    def upload_pipeline_model_version(self, model_id, version_id, binary_data):
        r = http.request('PUT', '{}/v2/artifacts/pipelines/{}/versions/{}/content'.format(
            self.repository_path,
            model_id,
            version_id
        ),
            headers=self._get_headers(),
            body=binary_data
        )
        if r.status != 200:
            raise ApiException(r.status)

    def _get_headers(self, headers={}):
        tmp_headers = self.default_headers.copy()
        tmp_headers.update(headers)
        return tmp_headers
