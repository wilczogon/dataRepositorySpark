pipeline.DAG module
=======================

Module Context
--------------

.. automodule:: pipeline.DAG
    :members:
    :undoc-members:
