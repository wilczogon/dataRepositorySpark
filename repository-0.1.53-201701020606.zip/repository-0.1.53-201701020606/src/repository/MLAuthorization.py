import base64
import json


class MLAuthorization(object):
    def __init__(self, api_client, auth_api_client=None): # TODO additional client
        self.api_client = api_client
        self.auth_api_client = auth_api_client if auth_api_client is not None else api_client

    def add_header(self, key, value):
        self.api_client.set_default_header(key, value)
        self.auth_api_client.set_default_header(key, value)

    def password_authorize(self, user, password):
        encoded_credentials = base64.b64encode('{}:{}'.format(user, password))
        result = self.auth_api_client.call_api('/v2/identity/token', 'GET', {}, {},
                                      {
                                          'Authorization': 'Basic {}'.format(encoded_credentials),
                                          'Content-Type': 'text/plain'
                                      }, response_type='str'
                                      )
        token = json.loads(self.auth_api_client.last_response.data).get('token')
        self.token_authorize(token)

    def token_authorize(self, token):
        self.add_header('Authorization', 'Bearer {}'.format(token))
